Place the vosk model in here which you downloaded. Then extract all the files inside the vosk model
and copy it inside this 'model' folder. Then delete the vosk model folder.