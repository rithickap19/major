import os

os.startfile("C:\\Users\\joels\\AppData\\Local\\WhatsApp\\WhatsApp.exe")